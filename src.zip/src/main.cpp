#define NOMINMAX
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>
#include <random>
#include <chrono>
#include <cmath>
#include <map>
#include <algorithm>


#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "Engine/Drumsta.h"



// Graphcis
#include "Importer/AssetImporter.h"
#include "Datas/DatasType.h"
#include "Engine/Gameplay/Input/KeyboardInput.h"
#include "Engine/Rendering/OpenGL/Texture.h"
#include "Engine/Rendering/OpenGL/Shader.h"
#include <miniaudio.h>
#include "Engine/Rendering/GPUScene.h"
#include "Engine/Rendering/RenderingManager.h"
#include "Engine/Geometries/MeshGenerator.h"

//Audio

#include "Engine/Audio/Audio.h"


#include <stb_image.h>
#include <stb_image_write.h>



typedef GLuint gint;
GLFWwindow* window{ nullptr };

gint ssboVertex, ssboIndex, ssboTransform, ssboMetadata, indirectBuffer, vao, ssboColor;

std::vector<GLuint> shaderPrograms{};
std::vector<Mesh> meshes = {};
std::vector<Vertex>   allVertices;
std::vector<uint32_t> allIndices;
std::vector<DrawArraysIndirectCommand> drawCommands;
std::vector<DrawMetadata> drawMetadata;
std::vector<DrawColor> drawColor;
std::vector<glm::mat4x4> transforms;
std::vector<Texture> textures;



std::vector<std::string> vertexShaders{
    "Assets/Shaders/vertex.shader",
    "Assets/Shaders/newvertex.shader"
};

std::vector<std::string> fragmentShaders{
    "Assets/Shaders/frag.shader",
    "Assets/Shaders/newfrag.shader"
};







void initScene(GPUScene& gpuScene)
{



    // Shader Test
    Shader shader(vertexShaders[0], fragmentShaders[0]);
    shader.createShaderProgram();
    GLuint gpuShaderDI = shader.getGPUID();
    shaderPrograms.push_back(gpuShaderDI);
 //   createMeshData();

    uint32_t runningVertexOffset{ 0 };
    uint32_t runningIndexOffset{ 0 };
    std::cout << "Mesh Size: " << meshes.size() << std::endl;
    std::cout << "Transform Size: " << transforms.size() << std::endl;
    // Vertex
    for (int i{}; i < meshes.size(); i++)
    {
        const Mesh& mesh = meshes[i];
        allVertices.insert(allVertices.end(), mesh.verts.begin(), mesh.verts.end());
        allIndices.insert(allIndices.end(), mesh.indices.begin(), mesh.indices.end());

        DrawArraysIndirectCommand command;
        command.count = mesh.indexCount();
        command.instanceCount = 1;
        command.first = runningIndexOffset; // corrigé
        command.baseInstance = i;
        drawCommands.push_back(command);

        DrawMetadata meta;
        meta.baseVertex = runningVertexOffset;
        meta.materialIndex = mesh.materialId;
        drawMetadata.push_back(meta);
        runningVertexOffset += mesh.vertexCount();
        runningIndexOffset += mesh.indexCount();

    }

//    uploadSSBOToGpu();

    gpuScene.Upload(
        allVertices,
        allIndices,
        transforms,
        drawMetadata,
        drawColor,
        drawCommands
    );

}


void HandleCameraMovement(
    const KeyboardInput& inputDevice,
    glm::vec3& cameraPos,
    const float& camMovementSpeed

)
{

        //processInput(window, cameraPos);
        // -Z is away froim screren
        if (KeyboardInput::IsKeyPressed(GLFW_KEY_W))
        {
            cameraPos.z -= camMovementSpeed;
        }
        // +Z is into the screen
        if (KeyboardInput::IsKeyPressed(GLFW_KEY_S))
        {
            cameraPos.z += camMovementSpeed;
        }

        // -x is left
        if (KeyboardInput::IsKeyPressed(GLFW_KEY_A))
        {
            cameraPos.x -= camMovementSpeed;
        }
        // +x is right
        if (KeyboardInput::IsKeyPressed(GLFW_KEY_D))
        {
            cameraPos.x += camMovementSpeed;
        }

        // Up 
        if (KeyboardInput::IsKeyPressed(GLFW_KEY_Q))
        {
            cameraPos.y += camMovementSpeed;
        }
        // Down
        if (KeyboardInput::IsKeyPressed(GLFW_KEY_E))
        {
            cameraPos.y -= camMovementSpeed;
        }
}




int main()
{
    void();
    Drumsta app{};
    app.Start();
    app.ImportAsset("Assets/Models/hello.glb");
    app.InitScene();

    app.Run();
    return 1;

}